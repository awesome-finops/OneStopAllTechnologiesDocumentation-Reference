package com.accenture.chicagocrime;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;

 class AwsKinesisClient {

    public static final String AWS_ACCESS_KEY = "aws.accessKeyId";
    public static final String AWS_SECRET_KEY = "aws.secretKey";

    static {
        //add your AWS account access key and secret key
    	
    	//acloudguru access key & secret access key
    	
        System.setProperty(AWS_ACCESS_KEY, "AKIA5BXTXGQTCB4HVBEV");
        System.setProperty(AWS_SECRET_KEY, "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");
    }

    public static AmazonKinesis getKinesisClient(){
        return AmazonKinesisClientBuilder.standard()
                .withRegion(Regions.US_EAST_1)
                .build();
        
     //   public static AmazonKinesisClientBuilder standard()
     //   Returns:
    //   Create new instance of builder with all defaults set.
    }
}
