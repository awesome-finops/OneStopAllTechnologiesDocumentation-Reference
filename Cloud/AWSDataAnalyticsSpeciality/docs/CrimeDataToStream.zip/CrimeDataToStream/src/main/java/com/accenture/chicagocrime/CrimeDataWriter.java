package com.accenture.chicagocrime;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.model.DescribeStreamRequest;
import com.amazonaws.services.kinesis.model.PutRecordRequest;
import com.amazonaws.services.kinesis.model.PutRecordResult;
import com.amazonaws.services.kinesis.model.PutRecordsRequestEntry;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder; 
//Gson (also known as Google Gson) is an open-source Java library to serialize and deserialize Java objects to (and from) JSON.


/**
 * Continuously sends simulated CrimeDataSet to Kinesis
 *
 */
public class CrimeDataWriter {

	Random random = new Random();

	public static void main(String[] args) throws InterruptedException {

		// 1. get client
		AmazonKinesis kinesisClient = AwsKinesisClient.getKinesisClient();

		sendData(kinesisClient);

	}

	
	
	
	
	private static void sendData(AmazonKinesis kinesisClient) {
		String path = null;
		File crimeDataFolder;
		Scanner crimeDataReader;

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		
		PutRecordsRequestEntry requestEntry = new PutRecordsRequestEntry();
		PutRecordRequest recordRequest = new PutRecordRequest();
		
		String sequenceNumberOfPreviousRecord = null;

		System.out.println("Enter Crime Dataset directory location -");
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			path = reader.readLine();
		} catch (IOException e2) {

			e2.printStackTrace();
		}
		crimeDataFolder = new File(path);
		File[] listOfFiles = crimeDataFolder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			File file = listOfFiles[i];
			if (file.isFile() && file.getName().endsWith(".csv")) {

				try {

					crimeDataReader = new Scanner(file);
					String header = crimeDataReader.nextLine();
					while (crimeDataReader.hasNextLine()) {
						String data = crimeDataReader.nextLine();
						String[] recordCols=data.split(",");
						String iucr_code=recordCols[4];
						
						recordRequest.setData(ByteBuffer.wrap(String.format(data).getBytes()));
						//Setting iucr_code as Partition Key
						recordRequest.setPartitionKey(iucr_code.trim());
						//recordRequest.setPartitionKey(UUID.randomUUID().toString());
						
						// 2. PutRecordRequest
						recordRequest.setStreamName("chicagoCrimeStream");
						recordRequest.setSequenceNumberForOrdering(sequenceNumberOfPreviousRecord);
						
						PutRecordResult putRecordResult = kinesisClient.putRecord(recordRequest);
						
						sequenceNumberOfPreviousRecord = putRecordResult.getSequenceNumber();
						String str=putRecordResult.toString();
						System.out.println(str);
						System.out.println("*********");
						

						/*
						 * if (putRecordResult.> 0) { System.out.println("Error occurred for records " +
						 * results.getFailedRecordCount()); } else {
						 * System.out.println("Data sent successfully..."); }
						 */

						System.out.println(data);
						Thread.sleep(1000);

					}
					crimeDataReader.close();
				} catch (FileNotFoundException e) {
					System.out.println("File Not Found, please enter proper location");
					e.printStackTrace();
				} catch (Exception e1) {
					System.out.println("An error occurred.");
					e1.printStackTrace();
				}
			}
		}

		System.out.println("Message published successfully");

	}
	
	

}
